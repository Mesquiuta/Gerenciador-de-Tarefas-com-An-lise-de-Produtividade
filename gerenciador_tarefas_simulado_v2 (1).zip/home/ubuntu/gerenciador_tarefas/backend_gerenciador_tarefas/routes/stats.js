import express from 'express';

// IMPORTANT: In a real app, this state should be shared properly (e.g., via a service layer or database).
// For this simulation, we are accessing the mock data defined in tarefas.js.
// This is NOT ideal but necessary for this specific simulation setup.
// We need a way to access the current state of mockTarefas from tarefas.js
// Let's assume for simulation purposes we can somehow get the current state.
// A better simulation would involve a shared in-memory store.

// *** Simplified Simulation Approach: Calculate stats based on initial mock data ***
// We will use the initial state defined in tarefas.js for calculation, acknowledging
// that it won't reflect runtime changes made via API calls in this simple simulation.
const initialMockTarefas = [
  { _id: 'mock1', titulo: 'Configurar Ambiente Frontend', descricao: 'Instalar dependências e iniciar o servidor de desenvolvimento React.', status: 'pendente', dataCriacao: new Date(Date.now() - 86400000) },
  { _id: 'mock2', titulo: 'Revisar Código Backend', descricao: 'Analisar estrutura, lógica e segurança do código Node.js/Express.', status: 'concluida', dataCriacao: new Date(Date.now() - 172800000), dataConclusao: new Date(Date.now() - 86400000) },
];

const router = express.Router();

// Simulate GET /api/stats/productivity
router.get('/productivity', (req, res) => {
  console.log('[MOCK STATS] Recebido GET /productivity');
  try {
    // Simulate calculations based on the *initial* mock data
    const totalTarefas = initialMockTarefas.length;
    const tarefasConcluidas = initialMockTarefas.filter(t => t.status === 'concluida').length;
    const tarefasPendentes = initialMockTarefas.filter(t => t.status === 'pendente').length;

    // Simulate data for a simple chart (e.g., tasks by status)
    const stats = {
      total: totalTarefas,
      concluidas: tarefasConcluidas,
      pendentes: tarefasPendentes,
      // Example data structure for a chart
      chartData: {
        labels: ['Pendentes', 'Concluídas'],
        datasets: [{
          label: 'Status das Tarefas (Simulado)',
          data: [tarefasPendentes, tarefasConcluidas],
          backgroundColor: [
            'rgba(255, 159, 64, 0.2)', // Orange
            'rgba(75, 192, 192, 0.2)', // Green
          ],
          borderColor: [
            'rgba(255, 159, 64, 1)',
            'rgba(75, 192, 192, 1)',
          ],
          borderWidth: 1
        }]
      }
    };

    console.log('[MOCK STATS] Retornando estatísticas simuladas:', stats);
    res.json(stats);

  } catch (err) {
    console.error('[MOCK STATS] Erro ao simular GET /productivity:', err);
    res.status(500).json({ erro: 'Erro interno ao simular estatísticas de produtividade.' });
  }
});

export default router;

