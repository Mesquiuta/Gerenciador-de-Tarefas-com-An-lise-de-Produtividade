import mongoose from 'mongoose';

const tarefaSchema = new mongoose.Schema({
  titulo: {
    type: String,
    required: true
  },
  descricao: {
    type: String
  },
  status: {
    type: String,
    enum: ['pendente', 'concluida'],
    default: 'pendente'
  },
  dataCriacao: {
    type: Date,
    default: Date.now
  },
  dataConclusao: {
    type: Date
  }
});

export default mongoose.model('Tarefa', tarefaSchema);
