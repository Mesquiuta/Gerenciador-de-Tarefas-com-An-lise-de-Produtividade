import express from 'express';
// import mongoose from 'mongoose'; // Comentado para simulação
import cors from 'cors';
import dotenv from 'dotenv';

import tarefaRoutes from './routes/tarefas.js';
import authRoutes from './routes/auth.js'; // Importar rotas de autenticação simulada
import statsRoutes from './routes/stats.js'; // Importar rotas de estatísticas simuladas

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Usando as rotas simuladas
app.use('/api/tarefas', tarefaRoutes);
app.use('/api/auth', authRoutes); // Usar rotas de autenticação simulada
app.use('/api/stats', statsRoutes); // Usar rotas de estatísticas simuladas

// Bloco de conexão com MongoDB comentado para permitir a simulação
/*
mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
  })
  .catch((error) => console.error('Erro ao conectar ao MongoDB:', error));
*/

// Iniciar o servidor diretamente para a simulação
app.listen(PORT, () => console.log(`[SIMULAÇÃO] Servidor rodando na porta ${PORT} com endpoints simulados (incluindo /api/auth e /api/stats).`));

