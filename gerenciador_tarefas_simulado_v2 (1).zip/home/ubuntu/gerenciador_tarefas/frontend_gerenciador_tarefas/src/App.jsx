import { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';
import ProductivityChart from './ProductivityChart'; // Importar o componente do gráfico

// Configuração da URL base da API (melhor prática do que hardcoding)
const API_URL = 'http://localhost:5000/api';

function App() {
  // Estado de Autenticação (Simulado)
  const [user, setUser] = useState(null); // Guarda o usuário logado simulado
  const [token, setToken] = useState(null); // Guarda o token simulado
  const [authMode, setAuthMode] = useState('login'); // 'login' ou 'register'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');

  // Estado das Tarefas
  const [tarefas, setTarefas] = useState([]);
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [taskError, setTaskError] = useState('');

  // Estado das Estatísticas (Simulado)
  const [statsData, setStatsData] = useState(null);
  const [statsError, setStatsError] = useState('');

  // --- Lógica de Autenticação Simulada ---

  useEffect(() => {
    // Simulação simples: verificar se há um token mock no estado
    // Em um app real, verificaríamos localStorage e chamaríamos /api/auth/me
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    setAuthError('');
    try {
      const res = await axios.post(`${API_URL}/auth/login`, { email, password });
      setUser(res.data.user);
      setToken(res.data.token);
      setEmail('');
      setPassword('');
    } catch (err) {
      console.error('Erro no login simulado:', err.response?.data?.erro || err.message);
      setAuthError(err.response?.data?.erro || 'Erro ao tentar fazer login.');
      setUser(null);
      setToken(null);
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    setAuthError('');
    try {
      const res = await axios.post(`${API_URL}/auth/register`, { email, password });
      setUser(res.data.user);
      setToken(res.data.token);
      setEmail('');
      setPassword('');
    } catch (err) {
      console.error('Erro no registro simulado:', err.response?.data?.erro || err.message);
      setAuthError(err.response?.data?.erro || 'Erro ao tentar registrar.');
      setUser(null);
      setToken(null);
    }
  };

  const handleLogout = async () => {
    setAuthError('');
    try {
      await axios.post(`${API_URL}/auth/logout`);
    } catch (err) {
      console.error('Erro no logout simulado:', err.response?.data?.erro || err.message);
    }
    setUser(null);
    setToken(null);
    setTarefas([]); // Limpar tarefas ao deslogar
    setStatsData(null); // Limpar estatísticas ao deslogar
  };

  // --- Lógica das Tarefas e Estatísticas ---

  // Busca tarefas e estatísticas se o usuário estiver logado (simulado)
  useEffect(() => {
    if (user) {
      buscarTarefas();
      buscarEstatisticas();
    }
  }, [user]);

  const buscarTarefas = async () => {
    setTaskError('');
    try {
      const res = await axios.get(`${API_URL}/tarefas`);
      setTarefas(res.data);
    } catch (err) {
      console.error('Erro ao buscar tarefas (simulado):', err.response?.data?.erro || err.message);
      setTaskError('Erro ao buscar tarefas.');
    }
  };

  const buscarEstatisticas = async () => {
    setStatsError('');
    try {
      const res = await axios.get(`${API_URL}/stats/productivity`);
      setStatsData(res.data.chartData); // Pega apenas os dados do gráfico
    } catch (err) {
      console.error('Erro ao buscar estatísticas (simulado):', err.response?.data?.erro || err.message);
      setStatsError('Erro ao buscar dados de produtividade.');
      setStatsData(null);
    }
  };

  const criarTarefa = async () => {
    if (!titulo.trim()) return;
    setTaskError('');
    try {
      await axios.post(`${API_URL}/tarefas`, { titulo, descricao });
      setTitulo('');
      setDescricao('');
      buscarTarefas();
      buscarEstatisticas(); // Atualiza estatísticas após criar (simulado)
    } catch (err) {
      console.error('Erro ao criar tarefa (simulado):', err.response?.data?.erro || err.message);
      setTaskError('Erro ao criar tarefa.');
    }
  };

  const alterarStatus = async (id, status) => {
    setTaskError('');
    try {
      await axios.put(`${API_URL}/tarefas/${id}`, {
        status: status === 'pendente' ? 'concluida' : 'pendente'
      });
      buscarTarefas();
      buscarEstatisticas(); // Atualiza estatísticas após alterar (simulado)
    } catch (err) {
      console.error('Erro ao atualizar tarefa (simulado):', err.response?.data?.erro || err.message);
      setTaskError('Erro ao atualizar status da tarefa.');
    }
  };

  const excluirTarefa = async (id) => {
    setTaskError('');
    try {
      await axios.delete(`${API_URL}/tarefas/${id}`);
      buscarTarefas();
      buscarEstatisticas(); // Atualiza estatísticas após excluir (simulado)
    } catch (err) {
      console.error('Erro ao deletar tarefa (simulado):', err.response?.data?.erro || err.message);
      setTaskError('Erro ao excluir tarefa.');
    }
  };

  // --- Renderização ---

  if (!user) {
    // Tela de Login/Registro Simulada
    return (
      <div className="container auth-container">
        <h1>{authMode === 'login' ? 'Login (Simulado)' : 'Registro (Simulado)'}</h1>
        <form onSubmit={authMode === 'login' ? handleLogin : handleRegister}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Senha"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          {authError && <p className="error-message">{authError}</p>}
          <button type="submit">{authMode === 'login' ? 'Entrar' : 'Registrar'}</button>
        </form>
        <button onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')} className="toggle-auth">
          {authMode === 'login' ? 'Não tem conta? Registre-se' : 'Já tem conta? Faça login'}
        </button>
        <p style={{ marginTop: '20px', fontSize: '0.8em', color: '#888' }}>
          Use email: teste@exemplo.com / senha: senha para logar com o usuário mock inicial.
        </p>
      </div>
    );
  }

  // Tela Principal do Gerenciador de Tarefas (após login simulado)
  return (
    <div className="container">
      <div className="header">
        <h1>Gerenciador de Tarefas</h1>
        <div className="user-info">
          <span>Logado como: {user.email} (Simulado)</span>
          <button onClick={handleLogout} className="logout-button">Sair</button>
        </div>
      </div>

      <div className="form">
        <h2>Nova Tarefa</h2>
        <input
          type="text"
          placeholder="Título"
          value={titulo}
          onChange={(e) => setTitulo(e.target.value)}
        />
        <textarea
          placeholder="Descrição"
          value={descricao}
          onChange={(e) => setDescricao(e.target.value)}
        ></textarea>
        <button onClick={criarTarefa}>Adicionar</button>
        {taskError && <p className="error-message">{taskError}</p>}
      </div>

      <h2>Minhas Tarefas</h2>
      <ul className="lista">
        {tarefas.length === 0 && !taskError && <p>Nenhuma tarefa encontrada.</p>}
        {tarefas.map((tarefa) => (
          <li key={tarefa._id} className={tarefa.status === 'concluida' ? 'concluida' : ''}>
            <h3>{tarefa.titulo}</h3>
            <p>{tarefa.descricao}</p>
            <div className="acoes">
              <button onClick={() => alterarStatus(tarefa._id, tarefa.status)}>
                {tarefa.status === 'pendente' ? 'Concluir' : 'Reabrir'}
              </button>
              <button onClick={() => excluirTarefa(tarefa._id)} className="excluir">Excluir</button>
            </div>
          </li>
        ))}
      </ul>

      {/* Área para Gráficos */}
      <div className="stats-area">
        <h2>Análise de Produtividade (Simulada)</h2>
        {statsError && <p className="error-message">{statsError}</p>}
        {statsData ? (
          <ProductivityChart chartData={statsData} />
        ) : (
          !statsError && <p>Carregando gráfico...</p>
        )}
      </div>
    </div>
  );
}

export default App;

