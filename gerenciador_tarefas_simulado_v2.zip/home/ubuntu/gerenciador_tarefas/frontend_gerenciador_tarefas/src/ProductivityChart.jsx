import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const ProductivityChart = ({ chartData }) => {
  if (!chartData || !chartData.labels || !chartData.datasets) {
    return <p>Carregando dados do gráfico...</p>;
  }

  const options = {
    responsive: true,
    plugins: {
      legend: {
        position: 'top',
      },
      title: {
        display: true,
        text: 'Visão Geral das Tarefas (Simulado)',
      },
    },
  };

  return <Bar options={options} data={chartData} />;
};

export default ProductivityChart;

