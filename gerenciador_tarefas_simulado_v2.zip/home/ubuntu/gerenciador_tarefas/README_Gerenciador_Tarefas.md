# Gerenciador de Tarefas com Análise de Produtividade

Este projeto é composto por uma aplicação web dividida em duas partes: **frontend em React** e **backend em Node.js com Express**, conectados a um banco de dados MongoDB.

## Funcionalidades
- Cadastro, listagem, conclusão e exclusão de tarefas
- Visualização do status de cada tarefa (pendente ou concluída)
- Interface limpa e responsiva
- Backend com API RESTful
- Estrutura de banco de dados MongoDB
- Pronto para expansão com gráficos de produtividade

---

## Estrutura do Projeto
```
📁 backend_gerenciador_tarefas
├── index.js
├── models/Tarefa.js
├── routes/tarefas.js
├── .env.example
└── package.json

📁 frontend_gerenciador_tarefas
├── index.html
├── package.json
└── src/
    ├── App.jsx
    ├── main.jsx
    └── App.css
```

---

## Como Executar Localmente

### Pré-requisitos:
- Node.js instalado
- Conta MongoDB Atlas (ou MongoDB local)
- Git (opcional)

---

### 1. Clonar ou extrair os arquivos

```bash
# Backend
cd backend_gerenciador_tarefas
npm install
cp .env.example .env  # e edite com sua URI do MongoDB
npm start
```

```bash
# Frontend
cd frontend_gerenciador_tarefas
npm install
npm run dev
```

A aplicação estará disponível em `http://localhost:5173` (frontend) e o backend em `http://localhost:5000`.

---

## Observações
- O sistema está preparado para ser hospedado em plataformas como Vercel (frontend) e Render (backend).
- O banco de dados pode ser conectado via MongoDB Atlas utilizando a URI correta no `.env`.

---

Desenvolvido como projeto integrador do curso de Tecnologia da Informação - UNIVESP.
