# Documentação e Limitações da Versão Simulada

Este documento descreve as funcionalidades implementadas na versão atual do Gerenciador de Tarefas e **destaca as limitações importantes decorrentes do uso de um ambiente simulado**, conforme solicitado.

## Funcionalidades Implementadas (Simuladas)

1.  **Autenticação de Usuários:**
    *   Implementadas telas e lógica de Login e Registro no frontend.
    *   Backend possui rotas simuladas (`/api/auth/login`, `/api/auth/register`, `/api/auth/logout`, `/api/auth/me`) que operam com um **armazenamento de usuários em memória**.
    *   **Limitação Crítica:** Não há persistência real de usuários nem segurança adequada. A senha é comparada em texto plano (apenas para fins de simulação). O estado de login não persiste entre reinicializações do servidor.
    *   Usuário de teste inicial: `teste@exemplo.com` / senha: `senha`.

2.  **Gerenciamento de Tarefas (CRUD):**
    *   As funcionalidades de Criar, Ler, Atualizar (status) e Deletar tarefas continuam operando.
    *   **Limitação:** As tarefas também são **armazenadas em memória** no backend simulado. Quaisquer alterações (criação, atualização, exclusão) são perdidas ao reiniciar o servidor backend.

3.  **Análise de Produtividade e Gráficos:**
    *   Implementada uma rota simulada no backend (`/api/stats/productivity`) que calcula estatísticas básicas (total, concluídas, pendentes).
    *   Frontend exibe um gráfico de barras (usando Chart.js) com o status das tarefas.
    *   **Limitação:** As estatísticas e o gráfico são baseados nos **dados mockados iniciais** ou no estado atual em memória das tarefas simuladas. Não refletem uma análise real e persistente da produtividade. A lógica de cálculo é simplificada.

## Considerações Gerais

*   **Ausência de Banco de Dados Real:** A principal limitação é a falta de conexão com um banco de dados real (MongoDB). Todas as operações que dependem de persistência (usuários, tarefas, histórico para análise) são simuladas em memória.
*   **Propósito:** Esta versão simulada serve principalmente para **demonstrar a estrutura do frontend**, a integração básica com uma API e a implementação visual das funcionalidades solicitadas (autenticação, gráficos).
*   **Não Produção:** Esta versão **não é adequada para uso em produção** devido à falta de persistência, segurança e robustez.

## Próximos Passos Recomendados (Para Versão Real)

1.  Resolver os problemas de conexão com o MongoDB Atlas (URI, permissões, DNS).
2.  Refatorar o backend para usar o Mongoose e interagir com o banco de dados real para persistir usuários e tarefas.
3.  Implementar um sistema de autenticação seguro (hashing de senhas, tokens JWT seguros, gerenciamento de sessão).
4.  Desenvolver a lógica real de análise de produtividade no backend, utilizando agregações do MongoDB para calcular métricas significativas com base nos dados persistidos.
5.  Aprimorar os gráficos no frontend para refletir as métricas reais e oferecer mais opções de visualização.
6.  Implementar as melhorias técnicas sugeridas na análise inicial (`analise_tecnica.md`).

