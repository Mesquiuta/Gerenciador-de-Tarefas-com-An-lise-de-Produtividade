import express from 'express';

const router = express.Router();

// Mock data store - Simulating MongoDB
let mockTarefas = [
  { _id: 'mock1', titulo: 'Configurar Ambiente Frontend', descricao: 'Instalar dependências e iniciar o servidor de desenvolvimento React.', status: 'pendente', dataCriacao: new Date(Date.now() - 86400000) }, // Created yesterday
  { _id: 'mock2', titulo: 'Revisar Código Backend', descricao: 'Analisar estrutura, lógica e segurança do código Node.js/Express.', status: 'concluida', dataCriacao: new Date(Date.now() - 172800000), dataConclusao: new Date(Date.now() - 86400000) }, // Created 2 days ago, completed yesterday
];
let nextId = 3; // Simple ID generator for mock data

// Simulate POST /api/tarefas
router.post('/', async (req, res) => {
  console.log('[MOCK] Recebido POST /api/tarefas com body:', req.body);
  try {
    if (!req.body || !req.body.titulo) {
      return res.status(400).json({ erro: 'Título da tarefa é obrigatório na simulação.' });
    }
    const novaTarefa = {
      _id: `mock${nextId++}`,
      titulo: req.body.titulo,
      descricao: req.body.descricao || '',
      status: req.body.status === 'concluida' ? 'concluida' : 'pendente',
      dataCriacao: new Date(),
      dataConclusao: req.body.status === 'concluida' ? new Date() : undefined,
    };
    mockTarefas.push(novaTarefa);
    console.log('[MOCK] Nova tarefa simulada adicionada:', novaTarefa);
    console.log('[MOCK] Estado atual das tarefas simuladas:', mockTarefas);
    res.status(201).json(novaTarefa);
  } catch (err) {
    console.error('[MOCK] Erro ao simular POST /api/tarefas:', err);
    res.status(500).json({ erro: 'Erro interno ao simular criação de tarefa.' });
  }
});

// Simulate GET /api/tarefas
router.get('/', async (req, res) => {
  console.log('[MOCK] Recebido GET /api/tarefas');
  try {
    // Simulate sorting by creation date descending
    const sortedTarefas = [...mockTarefas].sort((a, b) => b.dataCriacao.getTime() - a.dataCriacao.getTime());
    console.log('[MOCK] Retornando tarefas simuladas ordenadas:', sortedTarefas);
    res.json(sortedTarefas);
  } catch (err) {
    console.error('[MOCK] Erro ao simular GET /api/tarefas:', err);
    res.status(500).json({ erro: 'Erro interno ao simular busca de tarefas.' });
  }
});

// Simulate PUT /api/tarefas/:id
router.put('/:id', async (req, res) => {
  const id = req.params.id;
  console.log(`[MOCK] Recebido PUT /api/tarefas/${id} com body:`, req.body);
  try {
    const index = mockTarefas.findIndex(t => t._id === id);
    if (index !== -1) {
      // Update only provided fields
      const tarefaOriginal = mockTarefas[index];
      const tarefaAtualizada = { ...tarefaOriginal };

      if (req.body.titulo !== undefined) tarefaAtualizada.titulo = req.body.titulo;
      if (req.body.descricao !== undefined) tarefaAtualizada.descricao = req.body.descricao;
      if (req.body.status !== undefined) {
        tarefaAtualizada.status = req.body.status === 'concluida' ? 'concluida' : 'pendente';
        tarefaAtualizada.dataConclusao = tarefaAtualizada.status === 'concluida' ? (tarefaOriginal.dataConclusao || new Date()) : undefined;
      }

      mockTarefas[index] = tarefaAtualizada;
      console.log('[MOCK] Tarefa simulada atualizada:', tarefaAtualizada);
      console.log('[MOCK] Estado atual das tarefas simuladas:', mockTarefas);
      res.json(tarefaAtualizada);
    } else {
      console.log(`[MOCK] Tarefa simulada com ID ${id} não encontrada para PUT.`);
      res.status(404).json({ erro: 'Tarefa simulada não encontrada.' });
    }
  } catch (err) {
    console.error(`[MOCK] Erro ao simular PUT /api/tarefas/${id}:`, err);
    res.status(500).json({ erro: 'Erro interno ao simular atualização de tarefa.' });
  }
});

// Simulate DELETE /api/tarefas/:id
router.delete('/:id', async (req, res) => {
  const id = req.params.id;
  console.log(`[MOCK] Recebido DELETE /api/tarefas/${id}`);
  try {
    const initialLength = mockTarefas.length;
    mockTarefas = mockTarefas.filter(t => t._id !== id);
    if (mockTarefas.length < initialLength) {
      console.log(`[MOCK] Tarefa simulada com ID ${id} deletada.`);
      console.log('[MOCK] Estado atual das tarefas simuladas:', mockTarefas);
      res.json({ mensagem: 'Tarefa simulada deletada com sucesso.' });
    } else {
      console.log(`[MOCK] Tarefa simulada com ID ${id} não encontrada para DELETE.`);
      res.status(404).json({ erro: 'Tarefa simulada não encontrada.' });
    }
  } catch (err) {
    console.error(`[MOCK] Erro ao simular DELETE /api/tarefas/${id}:`, err);
    res.status(500).json({ erro: 'Erro interno ao simular deleção de tarefa.' });
  }
});

export default router;

