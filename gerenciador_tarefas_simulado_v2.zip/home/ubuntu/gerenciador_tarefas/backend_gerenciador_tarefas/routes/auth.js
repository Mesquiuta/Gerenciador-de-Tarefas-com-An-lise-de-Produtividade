import express from 'express';

const router = express.Router();

// Mock user store (in-memory)
let mockUsers = [
  { id: 'user1', email: 'teste@exemplo.com', password: 'senha' } // Senha em texto plano apenas para simulação!
];
let loggedInUser = null; // Simula o usuário logado

// Simulate POST /api/auth/register
router.post('/register', (req, res) => {
  const { email, password } = req.body;
  console.log('[MOCK AUTH] Recebido POST /register com:', { email, password: '***' });
  if (!email || !password) {
    return res.status(400).json({ erro: 'Email e senha são obrigatórios para registro simulado.' });
  }
  if (mockUsers.find(u => u.email === email)) {
    return res.status(409).json({ erro: 'Email simulado já registrado.' });
  }
  const newUser = { id: `user${mockUsers.length + 1}`, email, password };
  mockUsers.push(newUser);
  console.log('[MOCK AUTH] Novo usuário simulado registrado:', { id: newUser.id, email: newUser.email });
  console.log('[MOCK AUTH] Usuários simulados atuais:', mockUsers.map(u => ({ id: u.id, email: u.email })));
  // Simula login automático após registro
  loggedInUser = { id: newUser.id, email: newUser.email };
  res.status(201).json({ token: `mockToken_${newUser.id}`, user: loggedInUser });
});

// Simulate POST /api/auth/login
router.post('/login', (req, res) => {
  const { email, password } = req.body;
  console.log('[MOCK AUTH] Recebido POST /login com:', { email, password: '***' });
  if (!email || !password) {
    return res.status(400).json({ erro: 'Email e senha são obrigatórios para login simulado.' });
  }
  const user = mockUsers.find(u => u.email === email && u.password === password);
  if (user) {
    loggedInUser = { id: user.id, email: user.email };
    console.log('[MOCK AUTH] Login simulado bem-sucedido para:', loggedInUser);
    res.json({ token: `mockToken_${user.id}`, user: loggedInUser });
  } else {
    console.log('[MOCK AUTH] Falha no login simulado para:', email);
    loggedInUser = null;
    res.status(401).json({ erro: 'Credenciais simuladas inválidas.' });
  }
});

// Simulate GET /api/auth/me (Check login status)
router.get('/me', (req, res) => {
  // Aqui poderíamos verificar um 'Authorization: Bearer mockToken_...' mas vamos simplificar
  console.log('[MOCK AUTH] Recebido GET /me. Usuário logado simulado:', loggedInUser);
  if (loggedInUser) {
    res.json({ user: loggedInUser });
  } else {
    res.status(401).json({ erro: 'Nenhum usuário simulado logado.' });
  }
});

// Simulate POST /api/auth/logout
router.post('/logout', (req, res) => {
  console.log('[MOCK AUTH] Recebido POST /logout. Deslogando usuário simulado:', loggedInUser);
  loggedInUser = null;
  res.json({ mensagem: 'Logout simulado realizado com sucesso.' });
});

export default router;

